
import socketLib.corp.wisrovi.socket.AnalisisDatosSocket;
import socketLib.corp.wisrovi.socket.Diccionarios.DiccionarioErrores;
import socketLib.corp.wisrovi.socket.Diccionarios.DiccionarioProcesos;
import socketLib.corp.wisrovi.socket.Dto.MatriculaDTO;
import socketLib.corp.wisrovi.socket.Dto.PinVidaDto;
import socketLib.corp.wisrovi.socket.Dto.ProtocoloComunicacionDto;
import socketLib.corp.wisrovi.socket.Lib.DefaultProcesos;
import socketLib.corp.wisrovi.socket.PropiedadesSocket;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author williamrodriguez
 */
public class probando extends AnalisisDatosSocket{
    
    class propiedades extends PropiedadesSocket{
        
    }

    @Override
    public ProtocoloComunicacionDto procesarDatos(String proceso, String datosComprimidos, DefaultProcesos defaultProcesos, ProtocoloComunicacionDto respuestaPorDefecto) {
        switch (proceso) {
            case DiccionarioProcesos.procesoSocketPinVida: {
                if (defaultProcesos.getPinVidaKeySocket() != 0) {
                    
                    
                    /*PinVidaDto datosPinVida = gson.fromJson(datosComprimidos, PinVidaDto.class);
                    String idDispositivo = datosPinVida.getIdDispositivo();
                    String ipDispositivo = datosPinVida.getIpDispositivo();*/

                    //guardo en base de datos el key, 
                    //para el dispositivo con 'idDispositivo' y con la ip 'ipDispositivo'
                } else {

                }

            }
            break;
            case DiccionarioProcesos.procesoSocketMatricula: {
                if (defaultProcesos.getMatricula()) {
                    /*MatriculaDTO datosMatricula = gson.fromJson(datosComprimidos, MatriculaDTO.class);
                    String identificadorUsuario = datosMatricula.getIdDispositivo();
                    String ipDispositivo = datosMatricula.getIpDispositivo();*/
                    //proceso a realizar cuando se realice correctamente la matricula
                }
            }
            break;
            default: {
                //el sistema devuelve de manera automatica un error
                //pero esta linea permite procesar de alguna manera el error para corregirlo o informarlo
                respuestaPorDefecto.setMsgError(DiccionarioErrores.msgErrorNoExisteProceso);
            }
            break;
        }
        return super.procesarDatos(proceso, datosComprimidos, defaultProcesos, respuestaPorDefecto); //To change body of generated methods, choose Tools | Templates.
    }
    
}
